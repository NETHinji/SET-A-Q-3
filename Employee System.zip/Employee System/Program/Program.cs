﻿using Program;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee[] employees = new Employee[5];

                //Adding 5 employees records
                for (int i = 0; i < 5; i++)
                    employees[i] = new Employee();
                for (int j = 0; j < 5; j++)
                {
                    Console.WriteLine("Enter Id:\n");
                    employees[j].ID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Name:\n");
                    employees[j].Name = Console.ReadLine();
                    Console.WriteLine("Enter location:\n");
                    employees[j].Location = Console.ReadLine();

                }
                Console.WriteLine("*****Employee Details*****\n");
                foreach (var emp in Employee.DisplayEmployee(employees))
                {
                    Console.WriteLine(emp.ID + "\t" + emp.Name + "\t" + emp.Location);
                }
                Console.ReadLine();
            }
            catch ( SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
